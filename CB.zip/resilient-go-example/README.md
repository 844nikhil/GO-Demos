## Resilient Go Example

* Making HTTP Client more Resilient in Go example

## Tests
```
make test
```

## Badges

[![Build Status](https://travis-ci.org/rafaeljesus/resilient-go-example.svg?branch=master)](https://travis-ci.org/rafaeljesus/resilient-go-example)
[![Go Report Card](https://goreportcard.com/badge/github.com/rafaeljesus/resilient-go-example)](https://goreportcard.com/report/github.com/rafaeljesus/resilient-go-example)
[![Go Doc](https://godoc.org/github.com/rafaeljesus/resilient-go-example?status.svg)](https://godoc.org/github.com/rafaeljesus/resilient-go-example)

---

> GitHub [@rafaeljesus](https://github.com/rafaeljesus) &nbsp;&middot;&nbsp;
> Medium [@_jesus_rafael](https://medium.com/@_jesus_rafael) &nbsp;&middot;&nbsp;
> Twitter [@_jesus_rafael](https://twitter.com/_jesus_rafael)
